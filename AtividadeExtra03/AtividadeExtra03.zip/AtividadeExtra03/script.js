function gerarTabuada(numero) {
    var texto = "<strong>** Tabuada do " + numero + " **</strong><br>";
    
    for (var i = 0; i <= 10; i++) {
        texto += numero + " x " + i + " = " + (numero * i) + "<br>";
    }
    
    return texto;
}

var num = parseInt(prompt("Digite um número inteiro entre 1 e 10:"));

while (isNaN(num) || num < 1 || num > 10) {
    num = parseInt(prompt("Número inválido! Digite um número inteiro entre 1 e 10:"));
}

var tabuadaFormatada = gerarTabuada(num);
document.getElementById("resultado").innerHTML = tabuadaFormatada;
