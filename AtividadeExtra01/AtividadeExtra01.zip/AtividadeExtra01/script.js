function calcularIMC() {
    
    var altura = parseFloat(document.getElementById("altura").value);
    var peso = parseFloat(document.getElementById("peso").value);
    var divResultado = document.getElementById("resultado");

    
    if (isNaN(altura) || isNaN(peso) || altura <= 0 || peso <= 0) {
        alert("Por favor, preencha a altura e o peso corretamente!");
        return;
    }


    var imc = peso / (altura * altura);
    var classificacao = "";
    var grauObesidade = "";


    if (imc < 18.5) {
        classificacao = "MAGREZA";
        grauObesidade = "0";
    } else if (imc >= 18.5 && imc <= 24.9) {
        classificacao = "NORMAL";
        grauObesidade = "0";
    } else if (imc >= 25.0 && imc <= 29.9) {
        classificacao = "SOBREPESO";
        grauObesidade = "I";
    } else if (imc >= 30.0 && imc <= 39.9) {
        classificacao = "OBESIDADE";
        grauObesidade = "II";
    } else {
        classificacao = "OBESIDADE GRAVE";
        grauObesidade = "III";
    }


    divResultado.innerHTML = 
        "<strong>Seu IMC:</strong> " + imc.toFixed(2) + "<br>" +
        "<strong>Classificação:</strong> " + classificacao + "<br>" +
        "<strong>Obesidade (Grau):</strong> " + grauObesidade;
}
