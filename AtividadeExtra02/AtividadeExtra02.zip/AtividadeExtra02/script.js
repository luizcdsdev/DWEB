
var numeros = [];

for (var i = 0; i < 10; i++) {
    var valor = parseFloat(prompt("Digite o " + (i + 1) + "º número:"));
    
    while (isNaN(valor)) {
        valor = parseFloat(prompt("Valor inválido! Digite o " + (i + 1) + "º número:"));
    }
    
    numeros.push(valor);
}

var arrayOriginal = numeros.slice();

var arrayCrescente = numeros.slice();
arrayCrescente.sort(function(a, b) {
    return a - b;
});

var arrayDecrescente = arrayCrescente.slice();
arrayDecrescente.reverse();

var divSaida = document.getElementById("saida");

divSaida.innerHTML = 
    "<p><strong>Array Original:</strong> " + arrayOriginal.join(", ") + "</p>" +
    "<p><strong>Ordem Crescente:</strong> " + arrayCrescente.join(", ") + "</p>" +
    "<p><strong>Ordem Decrescente:</strong> " + arrayDecrescente.join(", ") + "</p>";
