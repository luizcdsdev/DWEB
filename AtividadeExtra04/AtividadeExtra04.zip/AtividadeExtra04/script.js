function ordenarDecrescente(lista) {
    var copia = lista.slice();
    copia.sort(function(a, b) {
        return b - a;
    });
    return copia;
}

var numeros = [];

for (var i = 0; i < 5; i++) {
    var valor = parseFloat(prompt("Digite o " + (i + 1) + "º número:"));
    
    while (isNaN(valor)) {
        valor = parseFloat(prompt("Valor inválido! Digite o " + (i + 1) + "º número:"));
    }
    
    numeros.push(valor);
}

var resultadoOrdenado = ordenarDecrescente(numeros);

var divSaida = document.getElementById("saida");
divSaida.innerHTML = 
    "<p><strong>Array Original:</strong> " + numeros.join(", ") + "</p>" +
    "<p><strong>Ordem Decrescente:</strong> " + resultadoOrdenado.join(", ") + "</p>";
